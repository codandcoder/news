<table width="770" border="0" cellspacing="0"  align="center"  cellpadding="0" class="body">
    <tr>
      <td valign="top" class="leftright" style="padding-top:5px;">
		<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
		  <tr>
			<td background="images/line5x5.gif"><img src="images/spacer.gif" height="5" /></td>
		  </tr>
		  <tr>
			<td height="20" class="footer" valign="top">
		<?=date("Y")?> &copy; <?=stripslashes($settings['site_title'])?>. T�m Haklar� Sakl�d�r.<br />
						Yaz�l�m & Tasar�m : <a href="mailto:mahmuttt88@yahoo.com"><b>Mahmut �ZDEM�R</b></a> [ Cep : 0537 362 28 26 / Msn : mahmuttt@msn.com ]
			</td>
		  </tr>
		 </table>
	</td>
  </tr>
</table>
</body>
</html>