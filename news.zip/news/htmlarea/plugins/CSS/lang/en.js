// none yet; this file is a stub.
CSS.I18N = {};
