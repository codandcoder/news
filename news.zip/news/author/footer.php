  </td></tr>
 </table>
  <p align="center" style="color:#2F4457;">Yaz�l�m & Tasar�m : Mahmut �ZDEM�R [ cep : 05373622826 ]</p>
  </body>
</html>