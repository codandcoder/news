﻿-- ----------------------------
-- Table structure for gallery
-- ----------------------------
CREATE TABLE `gallery` (
  `gallery_id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `short_desc` char(200) default NULL,
  PRIMARY KEY  (`gallery_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for gallery_images
-- ----------------------------
CREATE TABLE `gallery_images` (
  `image_id` int(10) unsigned NOT NULL auto_increment,
  `gallery_id` int(10) unsigned NOT NULL,
  `short_desc` varchar(255) default NULL,
  `image` char(20) NOT NULL,
  `date` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `gallery` VALUES ('1', 'Deneme Galerisi', 'asdasd a');
INSERT INTO `gallery` VALUES ('2', 'dsad asdsad', 'asdsasa');
INSERT INTO `gallery` VALUES ('3', 'Deneme 3', 'Uluslararasý Para Fonu\\\'nun (IMF) son raporunda yer alan tahmini verilerinden derlenen bilgiye göre, Türkiye\\\'nin SGP\\\'ye göre kiþi baþýna yurtiçi milli geliri 2004 yýlýnda');
INSERT INTO `gallery_images` VALUES ('1', '3', 'ad sadsa dasd', '1.jpg', '1193089441');
INSERT INTO `gallery_images` VALUES ('2', '3', 'asd adad', '2.jpg', '1193089480');
INSERT INTO `gallery_images` VALUES ('3', '3', 'asdasda', '3.jpg', '1193089494');


-- ----------------------------
-- Table structure for gallery_images
-- ----------------------------
CREATE TABLE `gallery_images` (
  `image_id` int(10) unsigned NOT NULL auto_increment,
  `gallery_id` int(10) unsigned NOT NULL,
  `short_desc` varchar(255) default NULL,
  `image` char(20) NOT NULL,
  `date` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `gallery_images` VALUES ('1', '3', 'ad sadsa dasd', '1.jpg', '1193089441');
INSERT INTO `gallery_images` VALUES ('2', '3', 'asd adad', '2.jpg', '1193089480');
INSERT INTO `gallery_images` VALUES ('3', '3', 'asdasda', '3.jpg', '1193089494');
