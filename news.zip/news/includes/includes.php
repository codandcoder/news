<?php

	include_once("class/mysql.class.php");
	include_once("includes/db.php");
	include_once("includes/functions.php");
	include_once("includes/settings.php");
	include_once("includes/reklamlar.php");

?>