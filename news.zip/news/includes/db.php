<?php

$db = new mySQL;
$db->host = $dbhost;
$db->username = $dbuser;
$db->password = $dbpass;
$db->sql_connect($dbname);

?>