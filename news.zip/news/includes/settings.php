<?php

	$sql = "select site_title, site_url, site_slogan, site_email, active_poll,contact_address, contact_name, contact_tel, site_tags from settings";
			
	$query 	= $db->read_query($sql) or die($db->sql_error());
	$row 	= $db->sql_fetcharray($query);
	
	$settings	= array();
	
	$settings['site_title'] 				= stripslashes($row[site_title]);
	$settings['site_url']					= $row[site_url];
	$settings['site_slogan'] 				= stripslashes($row[site_slogan]);
	$settings['site_tags'] 					= stripslashes($row[site_tags]);
	$settings['contact_tel'] 				= stripslashes($row[contact_tel]);
	$settings['contact_address'] 			= stripslashes($row[contact_address]);
	$settings['contact_name'] 				= stripslashes($row[contact_name]);
	$settings['site_email']					= $row[site_email];
	$settings['active_poll']				= $row[active_poll];
	
	
	// Resim Tipleri
	$settings['image_type']					= array("jpg","gif","png");
	
	// Haber Resim Boyutlar�
	$settings['news_image_width']			= "260"; // pixel
	$settings['news_image_height']			= "180";
	
	// K��e Yazar� B�y�k Resim Boyut
	$settings['authors_big_width']			= "150";
	$settings['authors_big_height']			= "170";
	
	// K��e Yazar� K���k Resim Boyut
	$settings['authors_small_width']		= "38";
	$settings['authors_small_height']		= "46";
	
	// Sayfa ��i Max Resim Boyutu
	$settings['page_image_max_width']		= "470";
	
	// Max Dosy Boyutu KB
	$settings['image_size']					= "250";
	
	// Dosya Root Pathi
	$settings['root_path']					= $rootPath;
		
	$db->sql_freeresult($query);

?>